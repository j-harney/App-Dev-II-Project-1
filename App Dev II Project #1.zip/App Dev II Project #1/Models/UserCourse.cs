﻿using Microsoft.EntityFrameworkCore;

namespace App_Dev_II_Project__1.Models;

[PrimaryKey(nameof(takenCourseId), nameof(userId))]
public class UserCourse
{
	public int takenCourseId { get; set; }
	public string userId { get; set; }

	public bool PastCourse { get; set; }
}