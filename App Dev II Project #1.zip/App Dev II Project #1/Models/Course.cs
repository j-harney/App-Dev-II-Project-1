﻿namespace App_Dev_II_Project__1.Models;

public class Course
{
	public int courseId { get; set; }
	public string CourseTag { get; set; }
	public string CourseName { get; set; }

	public string CourseDescription { get; set; }
	public DateTime CourseBeginDate { get; set; }
	public DateTime CourseEndDate { get; set; }
	public int CourseCreditHours { get; set; }
}