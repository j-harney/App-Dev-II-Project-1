﻿using System.Dynamic;
using System.Security.Claims;
using App_Dev_II_Project__1.Data;
using App_Dev_II_Project__1.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace App_Dev_II_Project__1.Controllers;

public class CoursesController : Controller
{
	private readonly ApplicationDbContext _context;

	public CoursesController(ApplicationDbContext context)
	{
		_context = context;
	}

	private async Task<IActionResult> IndexCombined()
	{
		dynamic myModel = new ExpandoObject();
		myModel.Courses = await _context.Course.ToListAsync();
		myModel.UserCourses = await _context.UserCourse.ToListAsync();
		return View(myModel);
	}

	// GET: Courses
	[Authorize]
	public async Task<IActionResult> Index()
	{
		return View(await _context.Course.ToListAsync());
	}

	// GET : Courses/IndexCombinedCurrent
	[Authorize]
	public async Task<IActionResult> IndexCombinedCurrent()
	{
		var view = await IndexCombined();
		return view;
	}

	// GET : Courses/IndexCombinedPast
	[Authorize]
	public async Task<IActionResult> IndexCombinedPast()
	{
		var view = await IndexCombined();
		return view;
	}

	// GET: Courses/Details/5
	public async Task<IActionResult> Details(int? id)
	{
		if (id == null) return NotFound();

		var course = await _context.Course
			.FirstOrDefaultAsync(m => m.courseId == id);
		if (course == null) return NotFound();

		return View(course);
	}

	// GET: Courses/Create
	public IActionResult Create()
	{
		return View();
	}

	// POST: Courses/Create
	// To protect from overposting attacks, enable the specific properties you want to bind to.
	// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
	[HttpPost]
	[ValidateAntiForgeryToken]
	public async Task<IActionResult> Create(
		[Bind("courseId,CourseTag,CourseName,CourseDescription,CourseBeginDate,CourseEndDate,CourseCreditHours")]
		Course course)
	{
		if (ModelState.IsValid)
		{
			_context.Add(course);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		return View(course);
	}

	// GET: Courses/Edit/5
	public async Task<IActionResult> Edit(int? id)
	{
		if (id == null) return NotFound();

		var course = await _context.Course.FindAsync(id);
		if (course == null) return NotFound();
		return View(course);
	}

	// POST: Courses/Edit/5
	// To protect from overposting attacks, enable the specific properties you want to bind to.
	// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
	[HttpPost]
	[ValidateAntiForgeryToken]
	public async Task<IActionResult> Edit(int id,
		[Bind("courseId,CourseTag,CourseName,CourseDescription,CourseBeginDate,CourseEndDate,CourseCreditHours")]
		Course course)
	{
		if (id != course.courseId) return NotFound();

		if (ModelState.IsValid)
		{
			try
			{
				_context.Update(course);
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!CourseExists(course.courseId))
					return NotFound();
				throw;
			}

			return RedirectToAction(nameof(Index));
		}

		return View(course);
	}

	// GET: Courses/Delete/5
	public async Task<IActionResult> Delete(int? id)
	{
		if (id == null) return NotFound();

		var course = await _context.Course
			.FirstOrDefaultAsync(m => m.courseId == id);
		if (course == null) return NotFound();

		return View(course);
	}

	// POST: Courses/Delete/5
	[HttpPost]
	[ActionName("Delete")]
	[ValidateAntiForgeryToken]
	public async Task<IActionResult> DeleteConfirmed(int id)
	{
		var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
		var course = await _context.UserCourse.FindAsync(id, userId);
		if (course != null) _context.UserCourse.Remove(course);

		await _context.SaveChangesAsync();
		return RedirectToAction(nameof(Index));
	}

	private bool CourseExists(int id)
	{
		return _context.Course.Any(e => e.courseId == id);
	}
}