﻿using App_Dev_II_Project__1.Data;
using App_Dev_II_Project__1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace App_Dev_II_Project__1.Controllers;

public class UserCoursesController : Controller
{
	private readonly ApplicationDbContext _context;

	public UserCoursesController(ApplicationDbContext context)
	{
		_context = context;
	}

	// GET: UserCourses
	public async Task<IActionResult> Index()
	{
		return View(await _context.UserCourse.ToListAsync());
	}

	// GET: UserCourses/Details/5,userid
	public async Task<IActionResult> Details(int? id, string? userId)
	{
		if (id == null || userId == null) return NotFound();

		var userCourse = await _context.UserCourse
			.FirstOrDefaultAsync(m => m.takenCourseId == id && m.userId == userId);
		if (userCourse == null) return NotFound();

		return View(userCourse);
	}

	// GET: UserCourses/Create
	public IActionResult Create()
	{
		return View();
	}

	// POST: UserCourses/Create
	// To protect from overposting attacks, enable the specific properties you want to bind to.
	// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
	[HttpPost]
	[ValidateAntiForgeryToken]
	public async Task<IActionResult> Create([Bind("takenCourseId,userId,PastCourse")] UserCourse userCourse)
	{
		if (ModelState.IsValid)
		{
			_context.Add(userCourse);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		return View(userCourse);
	}

	// GET: UserCourses/Delete/5
	public async Task<IActionResult> Delete(int? id)
	{
		if (id == null) return NotFound();

		var userCourse = await _context.UserCourse
			.FirstOrDefaultAsync(m => m.takenCourseId == id);
		if (userCourse == null) return NotFound();

		return View(userCourse);
	}

	// POST: UserCourses/Delete/5
	[HttpPost]
	[ActionName("Delete")]
	[ValidateAntiForgeryToken]
	public async Task<IActionResult> DeleteConfirmed(int id, string userId)
	{
		var userCourse = await _context.UserCourse.FindAsync(id, userId);
		if (userCourse != null) _context.UserCourse.Remove(userCourse);

		await _context.SaveChangesAsync();
		return RedirectToAction(nameof(Index));
	}

	private bool UserCourseExists(int id)
	{
		return _context.UserCourse.Any(e => e.takenCourseId == id);
	}
}