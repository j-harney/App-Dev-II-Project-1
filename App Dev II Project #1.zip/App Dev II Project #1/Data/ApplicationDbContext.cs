﻿using App_Dev_II_Project__1.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace App_Dev_II_Project__1.Data;

public class ApplicationDbContext : IdentityDbContext
{
	public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
		: base(options)
	{
	}

	public ApplicationDbContext()
	{
	}

	public virtual DbSet<Course> Course { get; set; } = default!;
	public virtual DbSet<UserCourse> UserCourse { get; set; } = default!;
}