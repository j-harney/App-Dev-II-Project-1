﻿

namespace TestsForAppDev2Project1.ControllerTests
{
	public class CourseControllerTest
	{
		[Fact]
		public async Task Index_Test()
		{
			//Arrange
			var _courseController = new CourseController();
		}
	}
}
